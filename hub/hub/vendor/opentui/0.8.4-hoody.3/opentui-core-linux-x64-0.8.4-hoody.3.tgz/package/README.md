## @opentui/core-linux-x64

> Prebuilt linux-x64 binaries for `@opentui/core`.

`opentui.h` beside `libopentui.so` is the C ABI header that this library was built from (FNV-1a 64 `0x00b5e9a0b08f2fb9`). A C host compiles against it and links the library in this directory. For opentui-rust, set `OPENTUI_LIB_DIR` to this directory; its build fails when the header differs from the one its bindings were generated from. See [C](https://opentui.com/docs/native/c).