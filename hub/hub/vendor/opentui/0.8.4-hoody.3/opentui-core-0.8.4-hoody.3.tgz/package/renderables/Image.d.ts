import { Renderable, type RenderableOptions, type NativeRenderableIntegration } from "../Renderable.js";
import { NativeImage, type ExtractOptions, type ImageSource } from "../image.js";
import type { OptimizedBuffer } from "../buffer.js";
import type { ImageRenderProtocol, RenderContext, TerminalCapabilities } from "../types.js";
export type ImageFit = "fit" | "cover" | "fill";
export type ImageRenderableSource = ImageSource | NativeImage;
export interface ImageRenderableOptions extends RenderableOptions<ImageRenderable> {
    source?: ImageRenderableSource;
    fit?: ImageFit;
    /** The region of the source to show, in source pixels; `fit` applies to it. */
    crop?: ExtractOptions;
    protocol?: ImageRenderProtocol;
    onLoad?: (image: NativeImage) => void;
    onError?: (error: unknown) => void;
}
export declare function resolveImageRenderProtocol(requested: ImageRenderProtocol, capabilities: TerminalCapabilities | null, hasResolution: boolean): Exclude<ImageRenderProtocol, "auto">;
/** @internal Copies a crop of u32 pixels with a positive size that lies inside a width x height source, or throws. */
export declare function checkCrop(crop: ExtractOptions, width?: number, height?: number): ExtractOptions;
/** @internal */
export declare function sameCrop(a: ExtractOptions | undefined, b: ExtractOptions | undefined): boolean;
export declare class ImageRenderable extends Renderable {
    static readonly nativeIntegration: NativeRenderableIntegration;
    private _source;
    private _image;
    private _pendingImage;
    private _loadError;
    private _loadController;
    onLoad?: (image: NativeImage) => void;
    onError?: (error: unknown) => void;
    private _fit;
    private _crop;
    private _protocol;
    loadPromise: Promise<void> | null;
    constructor(ctx: RenderContext, options: ImageRenderableOptions);
    get source(): ImageRenderableSource | undefined;
    set source(source: ImageRenderableSource | undefined);
    get image(): NativeImage | null;
    get fit(): ImageFit;
    set fit(value: ImageFit | null | undefined);
    get crop(): ExtractOptions | undefined;
    /** A crop that is not whole pixels, or lies outside the loaded image, reports through onError and keeps the previous one. */
    set crop(value: ExtractOptions | null | undefined);
    get protocol(): ImageRenderProtocol;
    set protocol(value: ImageRenderProtocol | null | undefined);
    get effectiveProtocol(): Exclude<ImageRenderProtocol, "auto">;
    get cellAspectRatio(): number;
    getFittedSize(targetWidth: number, targetHeight: number, cellAspectRatio?: number, sourceWidth?: number, sourceHeight?: number): {
        width: number;
        height: number;
    };
    get loading(): boolean;
    get loadError(): unknown;
    protected createFrameBuffer(): void;
    protected renderSelf(buffer: OptimizedBuffer): void;
    private load;
    private region;
    private acceptCrop;
    private setNativeSceneImage;
    protected destroySelf(): void;
}
