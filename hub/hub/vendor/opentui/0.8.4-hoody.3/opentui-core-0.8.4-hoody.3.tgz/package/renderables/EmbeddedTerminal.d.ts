import { type RenderableOptions, Renderable, type NativeRenderableIntegration } from "../Renderable.js";
import type { KeyEvent, PasteEvent } from "../lib/KeyHandler.js";
import type { RenderContext } from "../types.js";
import type { OptimizedBuffer } from "../buffer.js";
import { type Selection } from "../lib/selection.js";
export type EmbeddedTerminalDataSource = "input" | "response";
export interface EmbeddedTerminalOptions extends RenderableOptions<EmbeddedTerminalRenderable> {
    cols?: number;
    rows?: number;
    maxScrollback?: number;
    transparentBackground?: boolean;
    onData?: (data: Uint8Array, source: EmbeddedTerminalDataSource) => void;
    onTerminalResize?: (cols: number, rows: number) => void;
    onScreenChange?: () => void;
    selectable?: boolean;
}
export type EmbeddedTerminalScreen = {
    text: string;
    lines: string[];
    columns: number;
    rows: number;
    cursor: {
        x: number;
        y: number;
        visible: boolean;
    };
};
export declare class EmbeddedTerminalRenderable extends Renderable {
    static readonly nativeIntegration: NativeRenderableIntegration;
    selectable: boolean;
    private readonly lib;
    private handle;
    private _onData?;
    private _onTerminalResize?;
    private _onScreenChange?;
    private keyreleaseHandler;
    private selection;
    private composedHookGeneration;
    private _transparentBackground;
    private readonly sizeDefaults;
    constructor(ctx: RenderContext, options: EmbeddedTerminalOptions);
    protected defaultDimension(kind: "width" | "height"): number;
    get onData(): ((data: Uint8Array, source: EmbeddedTerminalDataSource) => void) | undefined;
    set onData(value: ((data: Uint8Array, source: EmbeddedTerminalDataSource) => void) | undefined);
    get onTerminalResize(): ((cols: number, rows: number) => void) | undefined;
    set onTerminalResize(value: ((cols: number, rows: number) => void) | undefined);
    get onScreenChange(): (() => void) | undefined;
    set onScreenChange(value: (() => void) | undefined);
    get transparentBackground(): boolean;
    set transparentBackground(value: boolean);
    screen(): EmbeddedTerminalScreen;
    /** Rows from the live screen (0 there), total rows including the visible ones, and visible rows. */
    getScroll(): {
        offset: number;
        total: number;
        visible: number;
    };
    write(data: string | Uint8Array): void;
    invalidate(): void;
    encodeKey(key: KeyEvent): Uint8Array;
    encodePaste(bytes: Uint8Array): Uint8Array;
    shouldStartSelection(x: number, y: number): boolean;
    onSelectionChanged(selection: Selection | null): boolean;
    hasSelection(): boolean;
    getSelectedText(): string;
    focus(): void;
    blur(): void;
    handleKeyPress(key: KeyEvent): boolean;
    handlePaste(event: PasteEvent): void;
    protected onResize(width: number, height: number): void;
    protected _invokeNativePaint(buffer: OptimizedBuffer, deltaTime: number): void;
    protected renderSelf(buffer: OptimizedBuffer): void;
    protected destroySelf(): void;
    protected onRemove(): void;
    private setupMouse;
    private forwardMouse;
    private flushResponses;
    private sendFocus;
    private removeKeyreleaseHandler;
    private send;
}
