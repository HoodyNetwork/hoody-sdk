import type { BaseRenderable, RootRenderable, TextNodeRenderable, TextRenderable } from "@opentui/core";
import { baseComponents } from "../components/index.js";
export type Type = keyof typeof baseComponents;
export type Props = Record<string, any>;
export type Container = RootRenderable;
export type Instance = BaseRenderable;
/** A text node inside a text element, or a loose text block (text outside a text node). */
export type TextInstance = TextNodeRenderable | TextRenderable;
export type PublicInstance = Instance;
export type HostContext = Record<string, any> & {
    isInsideText?: boolean;
};
