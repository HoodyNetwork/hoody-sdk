/**
 * The one filter between React and the engine. Every string the React host hands an engine instance passes through
 * it: text instances and their updates, the props an instance is constructed with, and every prop (and style entry)
 * set on an instance afterwards, initial or updated. A host uses it to make text safe to draw (strip terminal control
 * sequences, refuse unsafe link targets, ...).
 *
 * Fail closed: until a filter is set, creating or updating any instance throws `TERM_UNSAFE_OUTPUT`, so nothing is
 * drawn unfiltered. A host that wants no filtering sets a pass-through filter explicitly.
 */
export interface HostTextFilter {
    /** A text instance's string, as it is created or updated. */
    text(s: string): string;
    /** The props an instance is constructed with. Return the same object when nothing changes. */
    props(p: object): object;
    /** One prop or style entry as it is set on an instance (initial set and every update). */
    prop(k: string, v: unknown): unknown;
}
/** Sets the filter for every root of this module instance; null removes it (rendering then throws). */
export declare function setHostTextFilter(f: HostTextFilter | null): void;
/** The filter in force. Throws when none is set (fail closed). */
export declare function hostTextFilter(): HostTextFilter;
