import React from "react";
type ErrorBoundaryProps = {
    children: React.ReactNode;
    resetKey: number;
};
type ErrorBoundaryState = {
    error: Error | null;
    resetKey?: number;
};
export declare class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
    state: ErrorBoundaryState;
    static getDerivedStateFromProps(props: ErrorBoundaryProps, state: ErrorBoundaryState): ErrorBoundaryState | null;
    static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState>;
    render(): any;
}
export {};
