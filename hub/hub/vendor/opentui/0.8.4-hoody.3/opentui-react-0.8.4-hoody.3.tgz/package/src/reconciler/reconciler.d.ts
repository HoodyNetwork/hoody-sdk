import type { RootRenderable } from "@opentui/core";
import ReactReconciler from "react-reconciler";
export declare const reconciler: ReactReconciler.Reconciler<RootRenderable, import("@opentui/core").BaseRenderable, import("@opentui/core").TextRenderable | import("@opentui/core").TextNodeRenderable, unknown, unknown, import("@opentui/core").BaseRenderable>;
export declare function createContainer(root: RootRenderable): any;
